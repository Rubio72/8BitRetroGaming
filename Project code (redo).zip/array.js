"use strict";

/*wishlist */

var item = ["Playstation 2, Nintendo GameCube, Nintendo Wii"];
var price = [69.99, 74.99, 64.99];
var qty = [3,2,5];

/*var title = document.getElementById('wishlist');

title.onclick = function(){
    alert("Added to wishlist");
}

function({
    alert("Added to wishlist");
}*/

