"use strict";


var title = document.getElementById('wishlist');

title.onclick = function(){
    alert("Added to wishlist");
}

function(){
    alert("Added to wishlist");
}

var prodlist = document.querySelectorAll('div');
//console.log(prodlist);
for (var i=0; i< prodlist.length; i++) { 
    divElem[i].style.backgroundColor="#99999940"; 
}